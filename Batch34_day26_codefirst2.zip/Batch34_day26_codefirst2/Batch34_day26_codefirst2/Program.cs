﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst2
{
    class Program
    {
        static void Main(string[] args)
        {
            MyDbContext db = new MyDbContext();
            try
            {
                Department d = new Department();
                d.DeptName = "Robotics";
                d.Location = "Chennai";
                db.Departments.Add(d);
                db.SaveChanges();
                Console.WriteLine("created");
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
