﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst2
{
    class Project
    {

        public int ProjectId { get; set; }
        public string Projname { get; set; }
        public string ClientName { get; set; }

        public virtual Department Department { get; set; }

    }
}
