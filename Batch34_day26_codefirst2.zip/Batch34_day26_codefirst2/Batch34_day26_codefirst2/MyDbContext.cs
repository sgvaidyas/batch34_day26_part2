﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Batch34_day26_codefirst2
{
    class MyDbContext:DbContext
    {
        public MyDbContext():base("Oct19_empdetails")
        {

        }
        public virtual DbSet<Department> Departments{ get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Project> Projects { get; set; }

    }
}
