﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst2
{
    class Department
    {

        public int DepartmentId { get; set; }
        public string DeptName { get; set; }
        public string Location { get; set; }

        //navigation
        public virtual ICollection<Employee> Employees { get; set; }
        public virtual ICollection<Project> Projects { get; set; }
    }
}
