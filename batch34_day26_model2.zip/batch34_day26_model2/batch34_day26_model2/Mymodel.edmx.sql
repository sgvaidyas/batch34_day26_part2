
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 10/19/2021 10:24:14
-- Generated from EDMX file: C:\Users\User\source\repos\batch34_day26_model2\batch34_day26_model2\Mymodel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Oct_19_films];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Actors'
CREATE TABLE [dbo].[Actors] (
    [ActorId] int IDENTITY(1,1) NOT NULL,
    [Actorname] nvarchar(max)  NOT NULL,
    [Age] int  NULL,
    [Phone] bigint  NOT NULL,
    [Email] nvarchar(max)  NOT NULL,
    [FilmId] int  NOT NULL
);
GO

-- Creating table 'Films'
CREATE TABLE [dbo].[Films] (
    [FilmId] int IDENTITY(1,1) NOT NULL,
    [FilmName] nvarchar(max)  NOT NULL,
    [Duration] real  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ActorId] in table 'Actors'
ALTER TABLE [dbo].[Actors]
ADD CONSTRAINT [PK_Actors]
    PRIMARY KEY CLUSTERED ([ActorId] ASC);
GO

-- Creating primary key on [FilmId] in table 'Films'
ALTER TABLE [dbo].[Films]
ADD CONSTRAINT [PK_Films]
    PRIMARY KEY CLUSTERED ([FilmId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [FilmId] in table 'Actors'
ALTER TABLE [dbo].[Actors]
ADD CONSTRAINT [FK_FilmActor]
    FOREIGN KEY ([FilmId])
    REFERENCES [dbo].[Films]
        ([FilmId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_FilmActor'
CREATE INDEX [IX_FK_FilmActor]
ON [dbo].[Actors]
    ([FilmId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------