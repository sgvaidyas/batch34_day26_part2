﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace batch34_day26_model2
{
    class Program
    {
        static void Main(string[] args)
        {
            MymodelContainer db = new MymodelContainer();

            Film f = new Film();
            f.FilmId = 11;
            f.FilmName = "Thor";
            f.Duration = 2;

            db.Films.Add(f);
            db.SaveChanges();


        }
    }
}
